import Vue from "vue";

// export const bus = new Vue();
export default new Vue();
