<template>
  <div>
    <div>공지사항 수정</div>
    <notice-input-item type="modify"></notice-input-item>
  </div>
</template>

<script>
import NoticeInputItem from "./NoticeInputItem.vue";

export default {
  components: { NoticeInputItem },
};
</script>

<style></style>
