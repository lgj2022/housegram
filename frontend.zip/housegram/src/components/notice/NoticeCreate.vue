<template>
  <div>
    <div>공지사항 생성</div>
    <notice-input-item type="regist"></notice-input-item>
  </div>
</template>

<script>
import NoticeInputItem from "./NoticeInputItem.vue";
export default {
  components: { NoticeInputItem },
};
</script>

<style></style>
