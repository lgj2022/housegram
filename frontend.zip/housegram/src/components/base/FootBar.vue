<template>
  <footer>Copyright by LEE MINWOO & LEE GIJIN in SSAFY 7th.</footer>
</template>

<script>
export default {};
</script>

<style scoped>
/* footer css */
footer {
  width: 100%;
  padding: 20px 0px;
  text-align: center;
  border: 0px;
  color: gray;
  background-color: #e8e7e7;
  position: absolute;
  bottom: 0px;
  z-index: 0;
}
</style>
