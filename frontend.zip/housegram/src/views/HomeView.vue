<template>
  <div class="home">
    <main-content></main-content>
  </div>
</template>

<script>
import MainContent from "@/components/base/MainContent.vue";
export default {
  name: "HomeView",
  components: { MainContent },
};
</script>
KakaoMap
